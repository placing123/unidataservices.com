
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
	<!-- *************
				************ Required JavaScript Files *************
			************* -->
		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="http://perfectjobcare.com/customer/assets/js/jquery.min.js"></script>
		<script src="http://perfectjobcare.com/customer/assets/js/bootstrap.bundle.min.js"></script>
		<script src="http://perfectjobcare.com/customer/assets/js/nav.min.js"></script>
		<script src="http://perfectjobcare.com/customer/assets/js/moment.js"></script>


		<!-- *************
				************ Vendor Js Files *************
			************* -->
		<!-- Daterange -->
		<script src="http://perfectjobcare.com/customer/assets/vendor/daterange/daterange.js"></script>

		<!-- Apex Charts -->
		<script src="http://perfectjobcare.com/customer/assets/vendor/apex/custom/apexLineChartGradient.js"></script>
		<script src="http://perfectjobcare.com/customer/assets/vendor/apex/custom/apexColumnBasic.js"></script>
		<script src="http://perfectjobcare.com/customer/assets/vendor/apex/custom/apexAllCustomGraphs.js"></script>

		<!-- Data Tables -->
		<script src="http://perfectjobcare.com/customer/assets/vendor/datatables/dataTables.min.js"></script>
		<script src="http://perfectjobcare.com/customer/assets/vendor/datatables/dataTables.bootstrap.min.js"></script>
		
		<!-- Custom Data tables -->
		<!-- <script src="assets/vendor/datatables/custom/custom-datatables.js"></script>
		<script src="assets/vendor/datatables/custom/fixedHeader.js"></script> -->
		<script>
			$(document).ready( function () {
			    $('#myTable').DataTable();
			} );
		</script>
		
		<!-- Main Js Required -->
		<script src="assets/js/main.js"></script>

	</body>
</html>