   <!-- Required Jquery -->


   
   <script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
   <script type="text/javascript"  src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.js"></script>

   <script  src="<?php  echo base_url().'customer_assets/js/custome.js'?>"></script>
   <script src="<?php  echo base_url().'customer_assets/bower_components/popper.js/js/popper.min.js'?>"></script>
   <script src="<?php  echo base_url().'customer_assets/bower_components/bootstrap/js/bootstrap.min.js'?>"></script>
   <script type="text/javascript" src="<?php  echo base_url().'customer_assets/bower_components/jquery-slimscroll/js/jquery.slimscroll.js'?>"></script>
    <!-- Float Chart js -->
    <!-- data-table js -->
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net/js/jquery.dataTables.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/pages/data-table/js/jszip.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/pages/data-table/js/pdfmake.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/pages/data-table/js/vfs_fonts.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net-buttons/js/buttons.print.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net-buttons/js/buttons.html5.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js'?>"></script>
    <!-- datatable end  -->
    
    <script src="<?php  echo base_url().'customer_assets/js/pcoded.min.js'?>"></script>
    <script src="<?php  echo base_url().'customer_assets/js/vertical/vertical-layout.min.js'?>"></script>
    <!-- <script type="text/javascript" src="<?php  echo base_url().'customer_assets/pages/dashboard/custom-dashboard.min.js'?>"></script> -->
    <script type="text/javascript" src="<?php  echo base_url().'customer_assets/js/script.min.js'?>"></script>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/numeric/1.2.6/numeric.min.js"></script>

<script type="text/javascript" src="<?php  echo base_url().'customer_assets/js/bezier.js'?>"></script>
<script type="text/javascript" src="<?php  echo base_url().'customer_assets/js/jquery.signaturepad.js'?>"></script>
<script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>




    



