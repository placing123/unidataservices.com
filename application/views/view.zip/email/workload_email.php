<?php 



$master_data = $this->model->hdm_get('tbl_master');

   $customer_care_no = $master_data[0]->care_no;
    $customer_care_no2 = $master_data[0]->care_no2;
   $care_eml = $master_data[0]->care_eml;
   $care_add = $master_data[0]->address;
   $company_name = $master_data[0]->name;


   $logo = base_url().$master_data[0]->logo;
   $seal = base_url().$master_data[0]->seal;

?>

<!DOCTYPE html>

<html>

<head>

  <meta charset="utf-8" />

  <title> <?php echo $company_name; ?></title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

</head>

<body>

<div>

  <div style="font-size: 26px;font-weight: 700;letter-spacing: -0.02em;line-height: 32px;color: #41637e;font-family: sans-serif;text-align: center" align="center" id="emb-email-header">
 
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px"><?php echo $company_name; ?> </p>
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Hi, </p>
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Congratulations for Joining <?php echo $company_name; ?>.</p>
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">As you know your agreement has been signed and now you are our registered freelancer. Your client Id & Password
     has been shared in the previous mail along with the website link. 
    You can now login and start your work. <strong>BEST OF LUCK!.</strong></p>
   
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Click here to login
    <?php echo base_url().'customer-login';?> </p>
  
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px"> Your ID : <?php echo $ID;?>   </p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px"> Your Password : <?php echo $password;?>   </p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Customer Support (10:30 AM to 6:30 PM): <?php echo $customer_care_no; ?>,<?php echo $customer_care_no2; ?>.</p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">According to the Electronic signatures facilitate faster and more secure document signing, with the flexibility to choose the option that is most efficient for each organization, department, or project. The U.S. Electronic Signatures in Global and National Commerce (ESIGN) Act in 2000 legislated that electronic signatures are legal in every state and U.S. territory where federal law applies. 

Electronic Signatures in Global and National Commerce (ESIGN) Act.
The ESIGN Act granted electronic signatures the same legal status as handwritten signatures throughout the United States, greatly simplifying and expediting how organizations gather, track, and manage signatures and approvals on agreements and documents of all kinds. In the ESIGN Act, an electronic signature is defined as “an electronic sound, symbol, or process attached to or logically associated with a contract or other record and executed or adopted by a person with the intent to sign the record.” In simple terms, electronic signatures are legally recognized as a viable method to indicate agreement to a contract.
The ESIGN Act:
Provides that any law with a requirement for a signature may be satisfied by an electronic signature
Allows electronically executed agreements to be presented as evidence in court
Prevents denial of legal effect, validity, or enforceability of an electronically signed document solely because it is in electronic form
For an electronic signature to be legally binding under the ESIGN Act, it is recommended that all electronic signature workflows include the following elements.

Intent to sign.

As with a handwritten signature, a signer must show clear intent to sign an agreement electronically. For example, signers can show intention by using a mouse to draw their signature, typing their name, or clicking an “Accept” button that is clearly labeled.

Consent to do business electronically.

Most electronic signature laws also require some form of consent to do business electronically. Many enterprise electronic signature solutions ask signers to “click to accept” a standard consent clause or provide an option to customize a consent clause such as:

The parties agree that this agreement may be electronically signed. The parties agree that the electronic signatures appearing on this agreement are the same as handwritten signatures for the purposes of validity, enforceability, and admissibility.

Opt-out clause.


</p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">If a signer elects to opt out of signing an agreement electronically, clear instructions on how to sign an agreement manually should be easily accessible as part of the signature workflow.

Signed copies.

All signers should receive a fully executed copy of the agreement. Many electronic signature solutions automatically provide executed copies of agreements to signers as part of the approval workflow.

Record retention.

Record retention requirements are addressed via the ESIGN Act, which legitimized the validity of electronic records as long as they accurately reflect the agreement and can be reproduced as required. Often this requirement is met by providing a fully executed copy to the signer or permitting the signer to download a copy of the agreement.</p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Best Regards,, </p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px"><?php echo $company_name;?> </p>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">  <strong>Disclaimer:  </strong>This email and any files transmitted with it are confidential and intended solely for the use of the individual or entity to which they are addressed. This message contains confidential information and is intended only for the individual named. If you are not the named addressee you should not disseminate, distribute or copy this e-mail. Please notify the sender immediately by e-mail if</p>
</div>

</body>

</html>