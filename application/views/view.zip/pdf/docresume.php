<div class="main" style="width: 80%; margin: auto; border-bottom: 5px solid #80808061;">
        <div class="first" style="height: 100px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 50%;">
                            <div class="logo" style="margin-left: 0px; width: 110px;">
                                <img src="<?= base_url('admin_assets/img/logo.jpeg') ?>" style="width: 100%; height: auto;">
                            </div>
                        </td>
                        <td>
                            
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="second">
            <table>
                <tbody>
                    <tr>
                        <td>
                            <h1 style="text-align: center; margin-top: -45px; margin-left: 100px; padding: 10px 20px; color: #fff; background-color: cornflowerblue;">
                                CLIENT OPENING SURVEY <br> FORM
                            </h1>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="third" style="margin-top: 25px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="width: 80%;text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"><?php echo $mis; ?></p>
                            <p style="width: 80%; text-align: center;color: black;">MR./MRS./MISS</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center;border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"><?php echo $first_name; ?></p>
                            <p style="text-align: center;color: black;">FIRST NAME</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center;border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"><?php echo $last_name; ?></p>
                            <p style="text-align: center;color: black;">LAST NAME</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="forth" style="margin-top: 25px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="text-align: center;width: 80%; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $contact_no; ?></p>
                            <p style="width: 80%; text-align: center;color: black;">CONTACT NUMBER</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center;border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $alternate_no; ?> </p>
                            <p style="text-align: center;color: black;">ALTERNATE NUMBER</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="five" style="width: 100%; margin-top: 30px;">
            <h3 style="text-align: center; border-top: 2px solid #000; border-bottom: 2px solid #000; background-color: #eee; padding: 8px 0px;">COMPANY DATA BASE</h3>
        </div>
        <div class="sixth" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="width: 80%; text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $email; ?>  </p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">EMAIL ADDRESS </p>
                        </td>
                        <td style="width: 20%;">
                            <p style="width: 80%;text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $company_name; ?>  </p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">COMPANY NAME</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">  <?php echo $website_url; ?>  </p>
                            <p style="text-align: center; padding-left: 0px;color: black;">WEBSITE URL</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="seven" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td>
                            <p style="text-align: left; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"><?php echo $address; ?>  </p>
                            <p style="text-align: left; padding-left: 0px;color: black;">Address</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="eight" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="text-align: center; width: 80%; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $city; ?></p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">City</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; width: 80%; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $state; ?> </p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">State</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;"> <?php echo $zip; ?> </p>
                            <p style="text-align: center; padding-left: 0px;color: black;">ZIP Code</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="nine" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td>
                            <p style="text-align: left; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">  <?php echo $sic_desc; ?></p>
                            <p style="text-align: left; padding-left: 0px;color: black;">SIC DESCRIPTION</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="forth" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="text-align: center; width: 80%; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">   <?php echo $sic_code; ?> </p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">SIC CODE</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">   <?php echo $entity_type; ?> </p>
                            <p style="text-align: center; padding-left: 0px;color: black;">ENTITY TYPE</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="forth" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="text-align: center; width: 80%; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">  <?php echo $company_sale; ?> </p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">COMPANY SALES</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">  <?php echo $revenue; ?> </p>
                            <p style="text-align: center; padding-left: 0px;color: black;">REVENUE (USD)</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="forth" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 20%;">
                            <p style="text-align: center; width: 80%; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">  <?php echo $country; ?> </p>
                            <p style="width: 80%; text-align: center; padding-left: 0px;color: black;">COUNTRY/REGION</p>
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; border-bottom: 1px solid #000;font-family: cursive;color: cornflowerblue;">    <?php echo $medical_ins; ?> </p>
                            <p style="text-align: center; padding-left: 0px;color: black;">MEDICAL INSURANCE</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <br><br><br>
     
    </div>

    <div class="main" style="width: 80%; margin: auto;">
    <div class="five" style="margin-top: 20px;">
            <table style="width: 100%;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 80%;">
                        <p style="width: 80%; text-align: center; padding-left: 0px;"><img src="<?= base_url('admin_assets/img/location.jpg') ?>" style="width: 15px; height: auto;"> </p>
                           
                        </td>
                        <td style="width: 20%;">
                        <p style="width: 80%; text-align: center; padding-left: 0px;"><img src="<?= base_url('admin_assets/img/call.png') ?>" style="width:15px; height: auto;"> </p>
                           
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="five" style="margin-top: 20px;">
            <table style="width: 100%;border-bottom:5px solid #80808061;">
                <tbody>
                    <tr style="width: 100%;">
                        <td style="width: 80%;">
                            <p style="text-align: left; width: 80%;"> US Hwy 1 S, Saint Augustine, FL 32086 ,Plantation Island Dr S, Saint Augustine, FL 32080</p>
                           
                        </td>
                        <td style="width: 20%;">
                            <p style="text-align: center; width: 80%;"> +1 (904) 117-1782 </p>
                           
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <br><br><br>
    </div>   
   
    <div class="page_break" style="page-break-before: always;"> </div> 
